public class NodeArray<T> extends Node<T> {
  int index;

  public NodeArray(T data) {
    super(data);
  }
}